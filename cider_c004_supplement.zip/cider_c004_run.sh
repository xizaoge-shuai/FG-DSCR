#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$(realpath "$0")")/../.."  # requires script at results/eq2_revision/
export PYTHONPATH="$PWD${PYTHONPATH:+:$PYTHONPATH}"
export PYTHONHASHSEED=0
ROOT="$PWD/results/eq2_revision/c004_content"
MODE="${1:-all}"
if [[ "$MODE" == prepare ]]; then
    python results/eq2_revision/cider_c004_content_experiment.py prepare
    exit
elif [[ "$MODE" == report ]]; then
    python results/eq2_revision/cider_c004_content_experiment.py report
    exit
elif [[ "$MODE" != all && "$MODE" != pilot ]]; then
    echo "用法: bash results/eq2_revision/cider_c004_run.sh prepare|pilot|all|report" >&2
    exit 2
fi
if [[ ! -f "$ROOT/manifest.json" ]]; then
    echo "请先执行 prepare" >&2
    exit 1
fi
mkdir -p "$ROOT/logs" "$ROOT/baselines"
mapfile -t CASES < <(python - <<'PY'
import json,hashlib
from pathlib import Path
m=json.loads(Path('results/eq2_revision/c004_content/manifest.json').read_text())
for e in m['cases']:
 p=Path(e['case'])
 if hashlib.sha256(p.read_bytes()).hexdigest()!=e['case_sha256']:
  raise RuntimeError('工作负载被修改: '+str(p))
 print(str(p))
PY
)
if [[ ${#CASES[@]} != 5 ]]; then echo '期望5组实验（原始 + 16/50/68/88）' >&2; exit 1; fi
if [[ "$MODE" == pilot ]]; then CASES=("${CASES[0]}"); fi

echo "[BASELINES] 总计 ${#CASES[@]} 个工作负载；输出在 $ROOT/baselines"
python -u -m secon_exp.experiments.run_scale_baselines_v2 \
  --cases "${CASES[@]}" --seeds 1 --wan 250 \
  --warmup-fraction 0.5 --core-capacity 1000 \
  --domain-capacity 300 --access-capacity 200 --peer-upload 12.5 \
  --registry-latency-ms 40 --inter-domain-latency-ms 10 \
  --intra-domain-latency-ms 2 \
  --baselines registry dragonfly_style peersync_style \
  --out "$ROOT/baselines" --resume \
  > "$ROOT/logs/baselines.log" 2>&1 || {
    tail -60 "$ROOT/logs/baselines.log" >&2; exit 1;
  }

echo '[CIDER] 在相同保存的预热状态和放置结果下测试'
for CASE in "${CASES[@]}"; do
    TAG="$(basename "$CASE" .json)"
    TAG="${TAG#cider_c004_}"
    OUT="$ROOT/cider/$TAG"
    mkdir -p "$OUT"
    if [[ -s "$OUT/raw.csv" ]]; then
        echo "[SKIP] $TAG"
        continue
    fi
    echo "[RUN] $TAG"
    python -u -m secon_exp.experiments.run_cider_mainline \
      --state-root "$ROOT/baselines/states" \
      --cases "$CASE" --seed 1 \
      --wan 250 --core-capacity 1000 --domain-capacity 300 \
      --access-capacity 200 --peer-upload 12.5 \
      --registry-latency-ms 40 --inter-domain-latency-ms 10 \
      --intra-domain-latency-ms 2 \
      --pulse-budget-mb 2048 --pulse-max-transfers 0 \
      --pulse-refill-ratio 0.5 \
      --scout-alpha 1 --scout-beta 4 --scout-gamma 0.5 \
      --scout-source-concurrency 0 \
      --keep-v 3e6 --keep-upper-budget-mb-s 150 \
      --ablation full --out "$OUT" \
      > "$ROOT/logs/cider_${TAG}.log" 2>&1 || {
        tail -60 "$ROOT/logs/cider_${TAG}.log" >&2; exit 1;
      }
    tail -4 "$ROOT/logs/cider_${TAG}.log"
done
if [[ "$MODE" == all ]]; then
    python results/eq2_revision/cider_c004_content_experiment.py report \
      > "$ROOT/logs/report.log" 2>&1 || {
      tail -70 "$ROOT/logs/report.log" >&2; exit 1;
    }
    cat "$ROOT/logs/report.log"
    echo 'COMPLETE' > "$ROOT/FINISHED.txt"
else
    python - "$ROOT/cider/original/raw.csv" <<'PY'
import csv,sys
with open(sys.argv[1],newline='',encoding='utf-8') as f:
    r=next(csv.DictReader(f))
mean=float(r['mean_ready_s']); p95=float(r['p95_ready_s'])
upper=float(r['registry_mb'])+float(r['cross_domain_peer_mb'])
print(f'[CONTROL] Mean={mean:.4f} P95={p95:.4f} Upper={upper:.1f}MB')
if int(r['accepted']) != 400 or abs(mean-10.88047)>0.03 or abs(p95-52.68245)>0.03 or abs(upper-29541)>1:
    raise SystemExit('[CONTROL FAILED] 基准复现不一致：先检查输入与预热状态，不要继续大批量实验')
print('[CONTROL PASSED] 可以执行 all')
PY
fi
