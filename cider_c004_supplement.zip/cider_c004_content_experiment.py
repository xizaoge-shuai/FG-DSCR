#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CIDER C004: controlled image-content workload generalization.

Use the local canonical arrival-aware 40-node case and existing real OCI layer
identities/sizes from previous FG-DSCR cases. No changes to algorithm code.
"""
from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import json
import random
from collections import Counter
from pathlib import Path

ROOT = Path.cwd()
OUT = ROOT / "results/eq2_revision/c004_content"
CASES = ROOT / "cases/cider_c004_content"
DONORS = {
    "img16": "cases/drtp_scale_prefix/drtp_img16_nodes18_cache1024mb_1000.json",
    "img50": "cases/drtp_scale_prefix/drtp_img50_nodes18_cache1024mb_200.json",
    "img68": "cases/drtp_uniform/drtp_uniform_img68_cache_1024mb_200.json",
    "img88": "cases/drtp_uniform88/drtp_uniform_img88_cache_1024mb_200.json",
}
# Sampling is fixed before any network experiments; do not tune by outcome.
SAMPLE_SEED = 20271011


def load(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))


def write(p, obj):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def canonical_case():
    ptr = ROOT / "results/LATEST_KEEP_CAPACITY_CORRECTED"
    if not ptr.is_file():
        raise FileNotFoundError(f"缺少正式状态指针: {ptr}")
    base = Path(ptr.read_text(encoding="utf-8").strip())
    if not base.is_absolute():
        base = ROOT / base
    manifest = load(base / "manifest.json")
    state_path = Path(manifest["source_state"])
    if not state_path.is_absolute():
        state_path = ROOT / state_path
    state = load(state_path)
    case_path = Path(state["case"])
    if not case_path.is_absolute():
        case_path = ROOT / case_path
    case_path = case_path.resolve()
    return case_path, load(case_path)


def validate_case(c, desc):
    if len(c["nodes"]) != 40 or len(c["containers"]) != 800:
        raise ValueError(f"{desc}: 应为40节点800请求")
    if not all("arrival_time_s" in x for x in c["containers"]):
        raise ValueError(f"{desc}: 缺少到达时刻")
    ids = [str(x["cid"]) for x in c["containers"]]
    if len(ids) != len(set(ids)):
        raise ValueError(f"{desc}: 请求编号重复")
    sizes = c["layer_sizes_mb"]
    needed = {l for x in c["containers"] for l in x["layers"]}
    if not needed <= sizes.keys():
        raise ValueError(f"{desc}: 存在缺少层大小的请求")
    if any(float(sizes[l]) <= 0 for l in needed):
        raise ValueError(f"{desc}: 层大小必须为正")
    huge = [(l, sizes[l]) for l in needed if float(sizes[l]) > 2048]
    if huge:
        raise ValueError(f"{desc}: 有{len(huge)}个层超过固定PULSE 2048MB预算，不能直接比较: {huge[:3]}")
    combos = {tuple(sorted(x["layers"])) for x in c["containers"]}
    return {"requests": len(ids), "unique_layers": len(needed),
            "unique_combinations": len(combos),
            "max_layer_mb": max(float(sizes[l]) for l in needed)}


def prepare():
    OUT.mkdir(parents=True, exist_ok=True)
    CASES.mkdir(parents=True, exist_ok=True)
    base_path, base = canonical_case()
    base_info = validate_case(base, "正式对照")
    # Original is a regression control: input has the same request identities,
    # image layer graph, arrival times, node resources and network topology.
    sources = [("original", base_path, base)]
    for tag, rel in DONORS.items():
        p = ROOT / rel
        if not p.is_file():
            raise FileNotFoundError(f"缺少已有镜像案例: {p}")
        d = load(p)
        if not d.get("containers") or not d.get("layer_sizes_mb"):
            raise ValueError(f"历史案例格式不完整: {p}")
        sources.append((tag, p, d))
    records = []
    orig_times = [(str(c["cid"]), float(c["arrival_time_s"])) for c in base["containers"]]
    for tag, src, donor in sources:
        c = copy.deepcopy(base)
        if tag != "original":
            # A controlled, trace-statistics-derived workload: change ONLY
            # the layer combinations/sizes; preserve 800 request IDs, arrival
            # times, service resource requirements and 40-node settings.
            samples = donor["containers"]
            rng = random.Random(SAMPLE_SEED)
            for request in c["containers"]:
                sampled = rng.choice(samples)
                request["layers"] = list(sampled["layers"])
            used = {l for req in c["containers"] for l in req["layers"]}
            c["layer_sizes_mb"] = {
                l: donor["layer_sizes_mb"][l] for l in sorted(used)
            }
        # Cleared during actual warm-up by the reference experiment runner.
        # Clearing here also prevents meaningless cache entries from old graphs.
        for node in c["nodes"]:
            node["initial_cache"] = []
        c.setdefault("metadata", {})["num_domains"] = 8
        c["metadata"]["c004_content_case"] = tag
        c["metadata"]["c004_donor"] = str(src.relative_to(ROOT))
        c["metadata"]["c004_note"] = (
            "Fixed request identities/arrival times/nodes/resources. "
            "Existing real Docker layer graph; request-layer mappings sampled "
            "with replacement from a historical derived FG-DSCR case. "
            "Not a new independent production trace."
        )
        info = validate_case(c, tag)
        this_times = [(str(r["cid"]), float(r["arrival_time_s"])) for r in c["containers"]]
        if orig_times != this_times:
            raise AssertionError("到达时序发生了变化")
        name = f"cider_c004_{tag}"
        path = CASES / f"{name}.json"
        write(path, c)
        rec = {"tag": tag, "case": str(path.relative_to(ROOT)),
               "case_sha256": sha(path), "donor": str(src.relative_to(ROOT)),
               "donor_sha256": sha(src), **info}
        records.append(rec)
        print(f"[{tag}] 请求={info['requests']} 组合={info['unique_combinations']} "
              f"不同层={info['unique_layers']} 最大层={info['max_layer_mb']:g}MB")
    write(OUT / "manifest.json", {
        "study": "C004 OCI image-layer composition generalization",
        "canonical_case": str(base_path.relative_to(ROOT)),
        "canonical_case_sha256": sha(base_path),
        "canonical_summary": base_info,
        "sample_seed": SAMPLE_SEED,
        "frozen_parameters": {"nodes": 40, "domains": 8, "requests": 800,
            "warmup_fraction": .5, "wan_mb_s": 250,
            "core_mb_s": 1000, "domain_mb_s": 300,
            "access_mb_s": 200, "peer_upload_mb_s": 12.5,
            "pulse_budget_mb": 2048, "pulse_refill_ratio": .5,
            "scout_alpha": 1, "scout_beta": 4, "scout_gamma": .5,
            "keep_v": 3e6, "keep_upper_budget_mb_s": 150},
        "important_limitations": [
            "Only image layer composition and its naturally evolving warm-up cache change.",
            "Donor cases may have different image popularity; this is multi-content robustness, not a pure image-count causal study.",
            "Request-image mappings are derived sampling, not independent IBM request replay.",
            "Parameters are frozen, but prior parameter development is not independent calibration.",
        ],
        "cases": records,
    })
    print("\n[生成完成]", OUT / "manifest.json")
    print("所有配置均使用原始请求身份/时序/节点资源，测试阶段重新进行历史预热。")


def report():
    manifest = load(OUT / "manifest.json")
    bs = OUT / "baselines/raw.csv"
    if not bs.is_file():
        raise FileNotFoundError(bs)
    with bs.open(newline="", encoding="utf-8") as f:
        baseline_rows = list(csv.DictReader(f))
    baseline_map = {(r["case"], r["baseline"]): r for r in baseline_rows}
    rows = []
    expected = ["registry", "dragonfly_style", "peersync_style", "cider"]
    for rec in manifest["cases"]:
        case = ROOT / rec["case"]
        if sha(case) != rec["case_sha256"]:
            raise RuntimeError(f"案例在运行后被修改: {case}")
        name = case.stem
        state = OUT / "baselines/states" / f"{name}__seed1.json"
        if not state.is_file():
            raise FileNotFoundError(state)
        s = load(state)
        if len(s["target_case"]["containers"]) != 400:
            raise RuntimeError("测试窗口请求数不为400")
        cider_csv = OUT / "cider" / rec["tag"] / "raw.csv"
        if not cider_csv.is_file():
            raise FileNotFoundError(cider_csv)
        with cider_csv.open(newline="", encoding="utf-8") as f:
            cider_data = list(csv.DictReader(f))
        if len(cider_data) != 1:
            raise RuntimeError(f"需要每组恰好一条CIDER记录: {cider_csv}")
        cider = cider_data[0]
        expected_accepted = sum(len(x) for x in s["placement"].values())
        if expected_accepted != 400:
            raise RuntimeError(f"{name}: 放置成功请求={expected_accepted}，不是400；禁止直接与正式400请求结果比较")
        for method in expected:
            r = cider if method == "cider" else baseline_map.get((name, method))
            if r is None:
                raise RuntimeError(f"未找到实验: {name} {method}")
            accepted = int(r["accepted"])
            if accepted != expected_accepted:
                raise RuntimeError(f"接受请求数不一致: {name} {method} {accepted} vs {expected_accepted}")
            upper = float(r["registry_mb"]) + float(r["cross_domain_peer_mb"])
            mean = float(r["mean_ready_s"])
            rows.append({
                "workload": rec["tag"], "method": method, "accepted": accepted,
                "unique_combinations": rec["unique_combinations"],
                "unique_layers": rec["unique_layers"],
                "mean_ready_s": mean, "p95_ready_s": float(r["p95_ready_s"]),
                "registry_mb": float(r["registry_mb"]),
                "same_domain_peer_mb": float(r["same_domain_peer_mb"]),
                "cross_domain_peer_mb": float(r["cross_domain_peer_mb"]),
                "upper_mb": upper, "upper_per_request_mb": upper / accepted,
                "objective_expression": f"{mean:.6f} + {upper/accepted:.6f}*lambda",
            })
    dst = OUT / "content_generalization_results.csv"
    with dst.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader(); w.writerows(rows)
    pretty = {"registry": "纯云端", "dragonfly_style": "蜻蜓式", "peersync_style": "多源协同", "cider": "完整方法"}
    lines = ["# 不同镜像层组合下的通信性能泛化实验", "",
             "真实镜像层摘要和大小取自此前的 Docker Hub 元数据衍生案例；"
             "部署请求按历史衍生样本重新组合，并非新增独立生产轨迹。", "",
             "固定 40 节点、8 域、800 请求、前 400 预热/后 400 测试，"
             "测试到达时序与网络参数不变；对每种镜像组合独立重新预热缓存。", "",
             "| 工作负载 | 方法 | 完成请求 | 平均层就绪时延（秒） | 95分位时延（秒） | 上层流量（MB） | 统一目标表达式 |",
             "|---|---|---:|---:|---:|---:|---|"]
    bykey = {(r["workload"],r["method"]):r for r in rows}
    for rec in manifest["cases"]:
        tag=rec["tag"]
        for method in expected:
            r=bykey[(tag,method)]
            lines.append(f"| {tag} | {pretty[method]} | {r['accepted']} | {r['mean_ready_s']:.3f} | "
                f"{r['p95_ready_s']:.3f} | {r['upper_mb']:.0f} | "
                f"{r['objective_expression'].replace('*lambda','λ')} |")
    lines += ["", "## 模型与结果解释边界", "",
              "- 这是不同真实镜像层组合形成的**派生工作负载**稳健性检验，而非多个独立真实生产轨迹。",
              "- 时间时序、节点规模、网络参数、资源需求一致；缓存因不同历史镜像请求而重新预热。",
              "- 不同历史案例具有不同镜像热度，不能将结果只归因于镜像数量。",
              "- 当前仅给出统一目标的形式表达式，λ 需在独立验证数据上预先确定。",
              "- 该实验不证明最初的算法参数曾在独立验证集标定。",
              ""]
    (OUT / "content_generalization_results.md").write_text("\n".join(lines), encoding="utf-8")
    print("\n====== 不同镜像内容下的实测结果 ======")
    for rec in manifest["cases"]:
        print("\n",rec["tag"], "真实组合数", rec["unique_combinations"], "层数",rec["unique_layers"])
        for method in expected:
            r=bykey[(rec["tag"],method)]
            print(f" {pretty[method]:<8} 完成={r['accepted']:3d} 平均={r['mean_ready_s']:8.3f} "
                f"P95={r['p95_ready_s']:8.3f} 上层={r['upper_mb']:9.0f} "
                f"J={r['objective_expression']}")
    print("\n[保存]", dst, "和", OUT/"content_generalization_results.md")


def main():
    p=argparse.ArgumentParser(description="C004 work with existing real image layer cases")
    p.add_argument("mode",choices=["prepare","report"])
    args=p.parse_args()
    if args.mode=="prepare": prepare()
    else: report()

if __name__=="__main__": main()
